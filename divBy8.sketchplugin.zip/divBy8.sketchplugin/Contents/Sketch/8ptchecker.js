/* 
Description:
Sketch Plugin to check if a value is divisible by 8 or 
if the selected layer's width and height are multiples of 8 

Author: Shivin Saxena
*/

//script variables
var base = 8; 
var app, doc, pages, userDefaults;

var nextMultiple, prevMultiple, remainder = 0;
var widthLabelMsg, heightLabelMsg;
var userValInput = 0, userValField;


var onRun = function(context) {
  
    //reference the Application
    app = [NSApplication sharedApplication];
    userDefaults = NSUserDefaults.alloc().initWithSuiteName("com.example.divBy8-plugin");


    //reference the Sketch Document
    doc = context.document;
    var selection = context.selection;
    
    
    if(selection.count() == 0){
        //if no layer is selected, show dialog to check the divisibility of a value
        var window = createValueCheckerWindow(context);
        var alert = window[0]; 
        var response = alert.runModal();
        
        if (response == "1000") {
        
            //save user input from textfields
            userValInput = parseFloat(userValField.stringValue());
            base = parseFloat(userBaseField.stringValue());

            //check divisibility by base
            remainder = userValInput % base;
            if(remainder != 0) { //not divisible
                prevMultiple = userValInput - remainder;
                nextMultiple = userValInput + (base - remainder);
                var resultMsg = userValInput + " is NOT divisble by " + base + ". You could use " + prevMultiple + " and " + nextMultiple + " instead.");
            }
            else { //is divisible
                prevMultiple = userValInput - base;
                nextMultiple = userValInput + base;
                var resultMsg = userValInput + " IS divisble by " + base + "! You could also use " + prevMultiple + " and " + nextMultiple + ".");
                //log("prev: " + prevMultiple + " and Next: " + nextMultiple);
            }
            doc.showMessage(resultMsg);
            return true;
        }
        
        
    }
    
    else if(selection.count() > 1) {
         doc.showMessage("Sorry! Only one layer can be selected.");               
    }
    
    else {
        //reference the selection
        var layer = selection[0];
        //get the layer frame for dimensions
        var layerFrame = layer.frame();
        //get the width
        var layerWidth = layerFrame.width();
        //get the height
        var layerHeight = layerFrame.height();
        
        remainder = isDivby8(layerWidth);
        if (remainder == 0) { 
            prevMultiple = layerWidth - base;
            nextMultiple = layerWidth + base;
            widthLabelMsg = "Width: " + layerWidth + " ✓    " + "⬆︎" + prevMultiple +  ", ⬇︎" + nextMultiple);       
        }
        else {
            prevMultiple = layerWidth - remainder;
            nextMultiple = layerWidth + (base - remainder);
            widthLabelMsg = "Width: " + layerWidth + " ✖︎    " + "⬆︎" + prevMultiple +  ", ⬇︎" + nextMultiple);
        }
        
        remainder = isDivby8(layerHeight);
        if (remainder == 0) { 
            prevMultiple = layerHeight - base;
            nextMultiple = layerHeight + base;
            heightLabelMsg = "Height: " + layerHeight + " ✓    " + "⬆︎" + prevMultiple +  ", ⬇︎" + nextMultiple);
        }
        else {
            prevMultiple = layerHeight - remainder;
            nextMultiple = layerHeight + (base - remainder);
            heightLabelMsg = "Height: " + layerHeight + " ✖︎    " + "⬆︎" + prevMultiple +  ", ⬇︎" + nextMultiple);
        }
        
        log(widthLabelMsg);
        log(heightLabelMsg);
        //create GUI dialog
        var window = createLayerCheckerWindow(context);
        var alert = window[0]; 
        var response = alert.runModal();
        
     }  
}

function isDivby8(val) {
    return (val % 8);
}


function createLayerCheckerWindow() {
    var alert = COSAlertWindow.new();

    alert.setMessageText("8-Point Check")

    // Creating dialog buttons
    alert.addButtonWithTitle("Done"); // response is 1000
    
    // Creating the view
    var viewWidth = 350;
    var viewHeight = 75;

    var view = NSView.alloc().initWithFrame(NSMakeRect(0, 0, viewWidth, viewHeight));
    alert.addAccessoryView(view);
    
    
    //creating the labels for the fields
    var objWidthLabel = NSTextField.alloc().initWithFrame(NSMakeRect(0, viewHeight - 60, 200, 25));
    objWidthLabel.setStringValue(widthLabelMsg);
    objWidthLabel.setSelectable(false);
    objWidthLabel.setEditable(false);
    objWidthLabel.setBezeled(false);
    objWidthLabel.setDrawsBackground(false);
    
    var objHeightLabel = NSTextField.alloc().initWithFrame(NSMakeRect(0, viewHeight - 25, 200, 15));
    objHeightLabel.setStringValue(heightLabelMsg);
    objHeightLabel.setSelectable(false);
    objHeightLabel.setEditable(false);
    objHeightLabel.setBezeled(false);
    objHeightLabel.setDrawsBackground(false);
    
    // Adding the textfield and labels to the view
    view.addSubview(objWidthLabel);
    view.addSubview(objHeightLabel);
    
    return [alert];
}

function createValueCheckerWindow() {
    var alert = COSAlertWindow.new();

    alert.setMessageText("Check Divisibility ...")

    // Creating dialog buttons
    alert.addButtonWithTitle("Go Math!"); // response is 1000
    alert.addButtonWithTitle("Nevermind"); // response is 1001
    
    // Creating the view
    var viewWidth = 350;
    var viewHeight = 75;

    var view = NSView.alloc().initWithFrame(NSMakeRect(0, 0, viewWidth, viewHeight));
    alert.addAccessoryView(view);
    
    // Creating the inputs fields
    userValField = NSTextField.alloc().initWithFrame(NSMakeRect(0, viewHeight - 40, 150, 20));
    userValField.setStringValue('0');
    userBaseField = NSTextField.alloc().initWithFrame(NSMakeRect(235, viewHeight - 40, 50, 20));
    userBaseField.setStringValue('8');

    //creating the labels for the fields
    var userValLabel = NSTextField.alloc().initWithFrame(NSMakeRect(0, viewHeight - 15, 150, 15));
    userValLabel.setStringValue("Enter Value:");
    userValLabel.setSelectable(false);
    userValLabel.setEditable(false);
    userValLabel.setBezeled(false);
    userValLabel.setDrawsBackground(false);
    
    var userBaseLabel = NSTextField.alloc().initWithFrame(NSMakeRect(235, viewHeight - 15, 50, 15));
    userBaseLabel.setStringValue("Base:");
    userBaseLabel.setSelectable(false);
    userBaseLabel.setEditable(false);
    userBaseLabel.setBezeled(false);
    userBaseLabel.setDrawsBackground(false);
    
    // Adding the textfield and labels to the view
    view.addSubview(userValField);
    view.addSubview(userBaseField);
    view.addSubview(userValLabel);
    view.addSubview(userBaseLabel);
    
    return [alert];

}